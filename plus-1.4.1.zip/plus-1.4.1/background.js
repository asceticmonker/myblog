chrome.extension.onMessage.addListener(function(objRequest, _, sendResponse){
    if(objRequest.api == 'license_auth') {

        $.ajax({
            url: 'http://120.27.148.29/license_auth',
            type: 'get',
            async: false,
            data: {'client_id': objRequest.client_id, rand: Math.random()},
            dataType: 'json',
            success: function(res) {
                if(res.code == 0) {
                    sendResponse({result: true});
                }
            }
        });
    }

    if(objRequest.api == 'license_reg') {
        $.ajax({
            url: 'http://120.27.148.29/license_reg',
            type: 'get',
            async: false,
            data: {'client_id': objRequest.client_id, sn: objRequest.sn, rand: Math.random()},
            dataType: 'json',
            success: function(res) {
                if(res.code == 0) {
                    sendResponse({result: true});
                }
            }
        });
    }

    if(objRequest.api == 'api/customs') {
        $.ajax({
            url: 'http://120.27.148.29/api/customs',
            type: 'get',
            async: false,
            data: {'client_id': objRequest.client_id, limit: objRequest.limit, rand: Math.random()},
            dataType: 'json',
            success: function(res) {
                sendResponse(res)
            }
        });
    }

    if(objRequest.api == 'api/custom_delete') {
        $.ajax({
            url: 'http://120.27.148.29/api/custom_delete',
            type: 'get',
            async: false,
            data: {'client_id': objRequest.client_id, id: objRequest.id, rand: Math.random()},
            dataType: 'json',
            success: function(res) {
                sendResponse(res)
            }
        });
    }
});