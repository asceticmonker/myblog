/**
 * Created by zhanglihe on 16/2/24.
 */
(function() {
    var upload = {
        status: 0,
        $button: $('#btnSubmit'),
        $sn: $('#client_id'),
        $loadText: $('#load-text'),
        init: function() {
            this.$button.on('click', function(e) {
                e.preventDefault();
                if(upload.status > 0) {
                    window.location.reload();
                    return false;
                }
                $('#myForm').submit();
                upload.uploading();
            });

            this.$sn.on('change', function(e) {
                if($(this).val() == '') {
                    return;
                }
                upload.setSn($(this).val());
            });

            $('#client_id').val(upload.getSn());
        },
        uploading: function() {
            this.status = 1;
            upload.$loadText.html('正在导入中，请不要关闭当前窗口。。。');
            this.$button.text('重新上传');
        },
        setSn: function(sn) {
            localStorage.setItem('sn', sn);
        },
        getSn: function() {
            return localStorage.getItem('sn');
        }
    };
    upload.init();
})();