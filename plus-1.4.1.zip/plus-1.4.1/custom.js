(function() {
    var pass = false;
    var el = function(dom, attrs) {
        var element = document.createElement(dom);
        for(var n in attrs) {
            element[n] = attrs[n];
        }
        return element;
    };
    var ghghgh = ['73C2929'];
    /*var upload = {
        status: 0,
        init: function() {
            $('#btnSubmit').on('click', function(e) {
                e.preventDefault();
                if(upload.status > 0) {
                    window.location.reload();
                    return false;
                }
                $('#myForm').submit();
                upload.uploading();
            });
        },
        uploading: function() {
            this.status = 1;
            $('#load-text').html('正在导入中，请不要关闭当前窗口。。。');
            $('#btnSubmit').text('重新上传');
            custom.isRender = false;
            custom.collectionLoaded = false;
        }
    };*/

    var custom = {
        hostname: window.location.hostname,
        //hostname: 'crm.189.cn',
        init: function() {
            //
        },
        items: [],
        _count: 0,
        isRender: false,
        collectionLoaded: false,
        event: function() {
            $('body').on('click', '#__BTN_SELECT', function(e) {
                e.preventDefault();
                //custom.unlock(); return false;
                custom.render();
            }).on('click', '#__BTN_IMPORT', function(e) {
                e.preventDefault();
                custom.upload();
            }).on('click', '#__BTN_CLOSE', function(e) {
                e.preventDefault();
                $('.allinone-list').hide();
            });
        },
        render: function() {
            if(!pass) {
                this.auth();
                return false;
            }
            if(!custom.collectionLoaded) {
                alert('号码库正在载入中，请稍后再试...');
            }
            if($('.allinone-list').is(':visible')) {
                $('.allinone-list').hide();
                return false;
            }
            if(custom.isRender) {
                $('.allinone-list').show();
                return false;
            }
            if(this.items.length == 0) {
                alert('请点击右上角的蓝色箭头，先导入号码库');
                return false;
            }
            console.log(this.items);
            $('#__CUSTOMS_LIST').html('');
            $.each(this.items, function() {
                custom.renderItem(this);
            });
            $('.allinone-list').show();
            this.isRender = true;
        },
        renderItem: function(item) {
            var _this = this;
            var el = $('<li data-name="'+item.name+'" data-num="'+item.id_num+'" ' +
            'data-address="'+item.address+'" data-present-address="'+item.present_address+'" onclick="javascript: window.__readCert(this);">'+item.name+item.id_num+'</li>');
            el.on('click', function(e) {
                chrome.extension.sendMessage({'api': 'api/custom_delete', 'client_id': _this.clientId, id: item.id}, function(d){
                    //
                });
                $(this).remove();
                _this.readCert(item);
                $('.allinone-list').hide();
            });
            $('#__CUSTOMS_LIST').append(el);
        },
        appendIcon: function() {
            $('body').append('<div class="allinone-buoy"><a href="#" id="__BTN_SELECT"><span>从号码库选择</span></a>' +
            '<a href="#" id="__BTN_IMPORT"><span>导入号码库</span></a>' +
                '</div>' +
            '<div class="allinone-list" style="display: none"><a href="#" id="__BTN_CLOSE">X</a> <ul id="__CUSTOMS_LIST"></ul></div>');
        },
        uploadForm: function() {
            /*return '<div class="__UPLOAD_FORM_CONTAINER">\
                        <div class="form">\
                    <form id="myForm" method="post" action="http://120.27.148.29/api/custom_upload" enctype="multipart/form-data" target="asyncTarget">\
                    <p><label>Excel文件：<input type="file" name="filedata" id="fileDate"></label>\
                    <input type="hidden" class="input-text" id="client_id" name="client_id" value="' + this.clientId + '"></lable>\
                    <button type="button" id="btnSubmit">导入</button></p>\
                    </form>\
                    </div>\
                    <div class="result">\
                    <h3>导入结果：<span id="load-text"></span></h3>\
                    <iframe name="asyncTarget" frameborder="0" style="height: 100px; overflow: hidden"></iframe>\
                    </div>\
                    </div>';*/
            return '<iframe src="http://120.27.148.29/upload" width="100%" height="350" frameborder="0"></iframe>';
        },
        upload: function() {
            artDialog({
                title: '从excel文件导入号码',
                width: 650,
                content: this.uploadForm(),
                ok: function() {
                    custom.getCollection();
                    custom.isRender = false;
                }
            }).show();
        },
        getEffDate: function() {
            var year = ['2006', '2007', '2008', '2009', '2010', '2011'];
            var month = ['01', '02', '03', '04', '05' , '06', '07', '08', '09', '10', '11', '12'];
            var day = ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28'];
            var y = this.randArray(year, 1), m = this.randArray(month, 1), d = this.randArray(day, 1);
            var exp = parseInt(y) + 10;
            return [y + '' + m + '' + d, exp + '' + m + '' + d];
        },
        randArray: function (m, len) {
            m.sort(function () {
                return Math.random() - 0.5;
            });
            return m.slice(0, len);
        }
    };
    console.log(custom.hostname);
    
    //全国系统
    if(custom.hostname == 'crm.189.cn') {
        $.extend(custom, {
            clientId: '',
            init: function() {
                var _this = this;
                this.licenseAuth();
            },
            getCollection: function() {
                var _this = this;
                /** 获取号码列表 */
                chrome.extension.sendMessage({'api': 'api/customs', 'client_id': this.clientId, limit: 100}, function(d){
                    console.log(d);
                    _this.items = d.data;
                    _this._count = d._count;
                    _this.collectionLoaded = true;
                });
            },
            init_2: function() {
                console.log(this.clientId)
                if(this.clientId == '') {
                    return false;
                }

                if (this.clientId !== $("#_session_staff_info").attr('staffcode')) {
                    return;
                }
                var _this = this;
                pass = true;
                $('#div_identidiesType').append(el('a', {
                    href:   'javascript:',
                    innerHTML : '手动输入',
                    onclick: function() {
                        console.log(pass);
                        pass = true;
                        if(!pass) {
                            _this.auth();
                            return false;
                        } else {
                            _this.unlock();
                        }
                    }
                }));
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.innerHTML = "cert = {readCert: function() {return {resultFlag: 0, resultContent: this.result}}, " +
                "result: {partyName: '', certNumber: '', certAddress: ''}}; " +
                "var __readCert = function(obj) {cert.result.partyName=$(obj).attr('data-name'); " +
                "cert.result.certNumber=$(obj).attr('data-num'); cert.result.certAddress=$(obj).attr('data-address'); " +
                "order.cust.readCertWhenCreate(); $('#cMailAddressStr').val($(obj).attr('data-present-address'));};" +
                "var _readCert = function() {order.cust.readCertWhenCreate();};";
                document.head.appendChild(script);
                document.head.removeChild(script);
                
                /** 号码库图标 */
                custom.appendIcon();
                custom.event();
                custom.getCollection();
            },
            
            unlock: function() {
                artDialog({
                    width: 400,
                    content: '客户姓名：<input type="text" id="__CUST_NAME" style="border: 1px solid #ddd; padding: 10px; width: 350px" onchange="javascript: cert.result.partyName = this.value; _readCert();">' +
                    '<br>证件号码：<input type="text" id="__CUST_ID_NUM" style="border: 1px solid #ddd; padding: 10px; width: 350px" onchange="javascript: cert.result.certNumber = this.value; _readCert();">' +
                    '<br>客户地址：<input type="text" id="__CUST_ADDRESS" style="border: 1px solid #ddd; padding: 10px; width: 350px" onchange="javascript: cert.result.certAddress = this.value; _readCert();">' +
                    '<br>通信地址：<input type="text" id="__CUST_MAIL_ADDRESS" style="border: 1px solid #ddd; padding: 10px; width: 350px">',
                    ok: function() {
                        /*cert.result.partyName = $('#__CUST_NAME').val();
                         cert.result.certNumber = $('#__CUST_ID_NUM').val();
                         cert.result.certAddress = $('#__CUST_ADDRESS').val();
                         __readCert();*/
                        $('#cMailAddressStr').val($('#__CUST_MAIL_ADDRESS').val());
                    }
                }).show();

                //document.getElementById('td_custName').innerHTML = '<input type="text" id="cCustName" class="inputWidth228px" onchange="javascript: cert.result.partyName = this.value; __readCert();">';
                //document.getElementById('td_custIdCard').innerHTML = '<input type="text" id="cCustIdCard" class="inputWidth228px" onchange="javascript: cert.result.certNumber = this.value; __readCert();">';
                //document.getElementById('td_addressStr').innerHTML = '<input type="text" id="cAddressStr" class="inputWidth228px" onchange="javascript: cert.result.certAddress = this.value; __readCert();">';
            },
            auth: function (callback) {
                var _this = this;
                artDialog({
                    title: '请输入工号(第一次使用需要输入工号):',
                    width: 300,
                    content: '<input type="text" id="__LICENSE_SN" style="border: 1px solid #ddd; padding: 10px;" size="20">',
                    ok: function() {
                        var sn = $('#__LICENSE_SN').val();
                        if(sn == '') {
                            return false;
                        }
                        if(!_this.licenseReg(sn)) {
                            alert('注册失败');
                            return false;
                        } else {
                            callback()
                        }
                    }
                }).show();
            },
            licenseReg: function(sn) {
                var result = false;
                if (ghghgh.indexOf(sn) > -1) {
                    result  = true;
                    this.clientId = sn;
                    chrome.storage.local.set({'get_user_num': sn})
                }
                return result;
            },
            licenseAuth: function() {
                console.log('slslsl')
                var result = false;
                var _this = this;
                chrome.storage.local.get('get_user_num', function(e) {
                    if (e && e.get_user_num && ghghgh.indexOf(e.get_user_num) > -1) {
                        _this.clientId = e.get_user_num;
                        _this.init_2()
                    } else {
                        _this.auth(_this.init_2);
                    }
                })
            },
            readCert: function(item) {
                //
            },
            upload: function() {
                window.open('http://120.27.148.29/upload');
            }
        });
    }

    //省系统
    if(custom.hostname == '115.233.6.84' || custom.hostname == '134.96.161.141') {
        $.extend(custom, {
            clientId: '',
            init: function() {
                var _this = this;
                
                this.licenseAuth();
                

            },
            init_2: function() {
                console.log(this.clientId)
                if(this.clientId == '') {
                    return false;
                }
                if ($("#loginId").val() !== this.clientId) {
                    return;
                }
                var _this = this;
                $('body').on('click', 'input[name="accountDo.idNum"],input[name="CUST_ID_NUM"]', function(e) {
                    e.preventDefault();
                    _this.inputCustIdNum();
                });

                if ($('#mainIframe').length > 0) {
                    artDialog({
                        content: '您当前是通过单点登录方式进入，需要重新加载后才能正常使用插件！',
                        ok: function() {
                            window.location.href = $('#mainIframe').attr('src');
                        }
                    }).show();
                    return false;
                }

                /** 号码库图标 */
                /*this.appendIcon();
                this.event();
                this.getCollection();*/

                //
                if (window.location.pathname == '/search/bill') {
                    $("#readIdCard").val(false);
                }

                $('input[name="accountDo.contactPhone"]').on('click', function() {
                    $(this).removeAttr('readonly').removeClass('color-lighter');
                });
                $('input[name="accountDo.mainContactPhone"]').on('click', function() {
                    $(this).removeAttr('readonly').removeClass('color-lighter');
                });
            },
            inputCustIdNum: function() {
                var _this = this;
                artDialog({
                    title: '请输入姓名及身份证号码:',
                    width: 400,
                    content: '姓名：<input type="text" id="__CUST_NAME" style="border: 1px solid #ddd; padding: 10px;" size="60"><br>' +
                    '号码：<input type="text" id="__CUST_ID_NUM" style="border: 1px solid #ddd; padding: 10px;" size="60"><br>' +
                    '地址：<input type="text" id="__CUST_ADDRESS" style="border: 1px solid #ddd; padding: 10px;" size="60"><br>' +
                    '发证机关：<input type="text" id="__CUST_CERT_ORG" style="border: 1px solid #ddd; padding: 10px;" size="60"><br>' +
                    '性别：<select id="__CUST_SEX"><option value="1">男</option><option value="2">女</option> </select>',
                    ok: function() {
                        var name = $('#__CUST_NAME').val();
                        var num = $('#__CUST_ID_NUM').val();
                        var address = $('#__CUST_ADDRESS').val();
                        var certOrg = $('#__CUST_CERT_ORG').val();
                        var sex = $('#__CUST_SEX').val();
                        if(name == '' || num == '' || address == '' || certOrg == '') {
                            alert('填写不全');
                            return false;
                        }
                        _this.setData({name: name, id_num: num, address: address, certOrg: certOrg, sex: sex});
                    }
                }).show();
            },
            auth: function (callback) {
                var _this = this;
                artDialog({
                    title: '请输入工号(第一次使用需要输入工号):',
                    width: 300,
                    content: '<input type="text" id="__LICENSE_SN" style="border: 1px solid #ddd; padding: 10px;" size="20">',
                    ok: function() {
                        var sn = $('#__LICENSE_SN').val();
                        if(sn == '') {
                            return false;
                        }
                        if(!_this.licenseReg(sn)) {
                            alert('注册失败');
                            return false;
                        } else {
                            callback()
                        }
                    }
                }).show();
            },
            licenseReg: function(sn) {
                var result = false;
                if (ghghgh.indexOf(sn) > -1) {
                    result  = true;
                    this.clientId = sn;
                    chrome.storage.local.set({'get_user_num': sn})
                }
                return result;
            },
            licenseAuth: function() {
                var result = false;
                var _this = this;
                chrome.storage.local.get('get_user_num', function(e) {
                    if (e && e.get_user_num && ghghgh.indexOf(e.get_user_num) > -1) {
                        _this.clientId = e.get_user_num;
                        _this.init_2()
                    } else {
                        _this.auth(_this.init_2);
                    }
                })
            },
            getCollection: function() {
                var _this = this;
                /** 获取号码列表 */
                chrome.extension.sendMessage({'api': 'api/customs', 'client_id': this.clientId, limit: 100}, function(d){
                    console.log(d);
                    _this.items = d.data;
                    _this._count = d._count;
                    _this.collectionLoaded = true;
                });
            },
            readCert: function(item) {
                $('input[name="CUST_NAME"]').val(item.name);
                $('input[name="CUST_ID_NUM"]').val(item.id_num);
                $('input[name="CUST_ID_NUM"]').val(item.id_num);
                $('#accntAddr').val(item.address);

                if(window.location.pathname == '/register') {
                    $('input[name="billAccntDo.name"]').val(item.name);
                    $('input[name="billAccntDo.billAdrr"]').val(item.address);
                }

                $('input[name="accountDo.name"]').val(item.name);
                $('input[name="accountDo.idNum"]').val(item.id_num);
                $('input[name="accountDo.accntAddr"]').val(item.address);
            },

            setData: function (item) {
                this.addReadLog(item);

                $('input[name="CUST_NAME"]').val(item.name);
                $('input[name="CUST_ID_NUM"]').val(item.id_num);
                $('input[name="CUST_ID_NUM"]').val(item.id_num);
                $('#accntAddr').val(item.address);

                if(window.location.pathname == '/register') {
                    $('input[name="billAccntDo.name"]').val(item.name);
                    $('input[name="billAccntDo.billAdrr"]').val(item.address);
                }

                $('input[name="accountDo.name"]').val(item.name);
                $('input[name="accountDo.idNum"]').val(item.id_num);
                $('input[name="accountDo.accntAddr"]').val(item.address);

                if(window.location.pathname == '/agent/return-file') {
                    $('#mainContactName').val(item.name);
                    $('#mainContactIdNumber').val(item.id_num);
                }

            },
            addReadLog: function(item) {
                var result = false;
                var bornday = item.id_num.substr(6, 8);
                var effDate = this.getEffDate();
                var certOrg = item.certOrg || '';
                $.ajax({
                    url: '/gzt/addIdCardReadLog',
                    type: 'POST',
                    async: false,
                    data: {
                        bornday: bornday,
                        address: item.address,
                        idNumber: item.id_num,
                        effDate: effDate[0],
                        expDate: effDate[1],
                        sex: item.sex,
                        nation: '汉',
                        name: item.name,
                        certOrg: certOrg
                    },
                    success: function() {
                        result = true;
                    },
                    error: function() {
                        alert('发送读卡日志失败');
                    }
                });
                return result;
            }
        });

    }

    if(custom.hostname == 'ccscm.chnl.zj.chinamobile.com') { //
        $.extend(custom, {
            clientId: $('.quick-menu').first('li').find('span').html(),
            init: function() {
                if(this.clientId == '') {
                    return false;
                }
                var _this = this;
                this.licenseAuth();
                $('#JS_readCustBtn').append(el('a', {
                    href:   'javascript:',
                    innerHTML : '手动输入',
                    onclick: function() {
                        console.log(pass);
                        pass = true;
                        if(!pass) {
                            _this.auth();
                            return false;
                        } else {
                            _this.unlock();
                        }
                    }
                }));

                if($('#mainIframe').length > 0) {
                    artDialog({
                        content: '您当前是通过单点登录方式进入，需要重新加载后才能正常使用插件！',
                        ok: function() {
                            window.location.href = $('#mainIframe').attr('src');
                        }
                    }).show();
                    return false;
                }

                /** 号码库图标 */
                this.appendIcon();
                this.event();
                this.getCollection();
            },
            inputCustIdNum: function() {
                artDialog({
                    title: '请输入姓名及身份证号码:',
                    width: 400,
                    content: '姓名：<input type="text" id="__CUST_NAME" style="border: 1px solid #ddd; padding: 10px;" size="60"><br>' +
                    '号码：<input type="text" id="__CUST_ID_NUM" style="border: 1px solid #ddd; padding: 10px;" size="60"><br>' +
                    '地址：<input type="text" id="__CUST_ADDRESS" style="border: 1px solid #ddd; padding: 10px;" size="60">',
                    ok: function() {
                        var name = $('#__CUST_NAME').val();
                        var num = $('#__CUST_ID_NUM').val();
                        var address = $('#__CUST_ADDRESS').val();
                        if(name == '' || num == '') {
                            return false;
                        }
                        $('input[name="CUST_NAME"]').val(name);
                        $('input[name="CUST_ID_NUM"]').val(num);
                        $('#accntAddr').val(address);
                        $('input[name="accountDo.name"]').val(name);
                        $('input[name="accountDo.idNum"]').val(num);
                        $('input[name="accountDo.accntAddr"]').val(address);
                    }
                }).show();
            },
            auth: function () {
                var _this = this;
                artDialog({
                    title: '请输入授权码:',
                    content: '<input type="text" id="__LICENSE_SN" style="border: 1px solid #ddd; padding: 10px;" size="20">',
                    ok: function() {
                        var sn = $('#__LICENSE_SN').val();
                        if(sn == '') {
                            return false;
                        }
                        if(!_this.licenseReg(sn)) {
                            alert('注册失败');
                            return false;
                        }
                    }
                }).show();
            },
            licenseReg: function(sn) {
                var result = false;
                $.ajax({
                    url: 'http://120.27.148.29/license_reg',
                    type: 'get',
                    async: false,
                    data: {'client_id': this.clientId, sn: sn, rand: Math.random()},
                    dataType: 'json',
                    success: function(res) {
                        if(res.code == 0) {
                            result = true;
                            pass = true;
                        }
                    }
                });
                return result;
            },
            licenseAuth: function() {
                var result = false;
                $.ajax({
                    url: 'http://120.27.148.29/license_auth',
                    type: 'get',
                    async: false,
                    data: {'client_id': this.clientId, rand: Math.random()},
                    dataType: 'json',
                    success: function(res) {
                        if(res.code == 0) {
                            result = true;
                            pass = true;
                        }
                    }
                });
                return result;
            },
            getCollection: function() {
                var _this = this;
                /** 获取号码列表 */
                chrome.extension.sendMessage({'api': 'api/customs', 'client_id': this.clientId, limit: 100}, function(d){
                    console.log(d);
                    _this.items = d.data;
                    _this._count = d._count;
                    _this.collectionLoaded = true;
                });
            },
            readCert: function(item) {
                $('input[name="CUST_NAME"]').val(item.name);
                $('input[name="CUST_CERT_CODE"]').val(item.id_num);
                $('input[name="CUST_CERT_ADDRESS"]').val(item.address);
                $('input[name="CUST_ADDRESS"]').val(item.present_address);
            }
        });
    }
    custom.init();
})();