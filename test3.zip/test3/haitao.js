var fs = require('fs')
var file1 = 'a1.txt'
var file2 = 'b1.txt'
var newData = [];
var data = fs.readFileSync(file1, 'utf8')
data = data.split('\n')
var str = '';
for (var i =0; i<data.length; i++) {
  var item = data[i].split(' ');

  // newData.push( [  Number(item[0]), Number(item[1])  ] )
  str = str + '[' + item[0] + ', ' + item[1] + '],\n';
}
// newData = JSON.stringify(newData, null, '\t')
fs.writeFileSync(file2, str, 'utf8')