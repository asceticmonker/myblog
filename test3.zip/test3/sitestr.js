var fs = require('fs')
var file1 = 'aaa.txt'
var file2 = 'bbb.txt'
var newData = [];
var data = fs.readFileSync(file1, 'utf8')
data = data.split('\n')
for (var i =0; i<data.length; i++) {
  newData.push( data[i] )
}
newData = JSON.stringify(newData, null, '\t')
fs.writeFileSync(file2, newData, 'utf8')