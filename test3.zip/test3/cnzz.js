var fs = require('fs')
var f1 = "jxdx.csv";
var f2 = "loader.csv";

var globalObj = {};
var strings = '域名,loader,jxdx,success\n';
var data1 = fs.readFileSync(f1, 'utf8')
var data2 = fs.readFileSync(f2, 'utf8')
data1 = data1.split('\n')
data2 = data2.split('\n')
var len1 = data1.length;
var len2 = data2.length;

for (var i=6; i<len2; i++) {
  var item = data2[i].split(',')
  globalObj[item[0]] = {
    'loader': item[1],
    'jxdx': '',
    'success': 0
  }
}

for (var i=6; i<len1; i++) {
  var item = data1[i].split(',')
  if (item[0] in globalObj) {
    globalObj[item[0]]['jxdx'] = item[1];
    var f = globalObj[item[0]]['loader'];
    var c = item[1];
    console.log(f)
    console.log(c)
    globalObj[item[0]]['success'] = parseInt( (Number(c)/Number(f))*1000 )/10;
    strings += item[0] + ',' + f + ',' + c + ','+ globalObj[item[0]]['success'] +  '\n';
  }
}

fs.writeFileSync('cnzz2.csv', strings, 'utf8')
fs.writeFileSync('cnzz.txt', JSON.stringify(globalObj, null, ' '), 'utf8')