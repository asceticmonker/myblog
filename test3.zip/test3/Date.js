function getRand() {
  var rand = 20;
  var week = new Date().getDay();
  var hour = new Date().getHours();
  if (week >= 1 && week <= 5 && hour >=7 && hour < 19) {
    rand = 10;
  }
  if (week >= 1 && week <=4 && (hour >= 19 || hour < 7) ) {
    rand = 20;
  }
  if ( (week === 5 && hour >= 19) || week === 6 || week === 7 || (week === 1 && hour < 7) ) {
    rand = 20;
  }
  return rand;
}